import { initMap } from "./map.js";
document.addEventListener("DOMContentLoaded", initMap);
